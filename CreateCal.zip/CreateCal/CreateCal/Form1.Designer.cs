﻿namespace CreateCal
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtOutput = new TextBox();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button17 = new Button();
            button19 = new Button();
            button20 = new Button();
            SuspendLayout();
            // 
            // txtOutput
            // 
            txtOutput.Font = new Font("Segoe UI", 14F);
            txtOutput.Location = new Point(12, 69);
            txtOutput.Name = "txtOutput";
            txtOutput.Size = new Size(358, 45);
            txtOutput.TabIndex = 3;
            // 
            // button13
            // 
            button13.BackColor = Color.LightCoral;
            button13.Font = new Font("Segoe UI", 14F);
            button13.Location = new Point(281, 120);
            button13.Name = "button13";
            button13.Size = new Size(89, 67);
            button13.TabIndex = 16;
            button13.Text = "/";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button_click;
            // 
            // button14
            // 
            button14.Font = new Font("Segoe UI", 14F);
            button14.Location = new Point(185, 120);
            button14.Name = "button14";
            button14.Size = new Size(90, 67);
            button14.TabIndex = 15;
            button14.Text = "%";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button_click;
            // 
            // button15
            // 
            button15.Font = new Font("Segoe UI", 14F);
            button15.Location = new Point(94, 120);
            button15.Name = "button15";
            button15.Size = new Size(85, 67);
            button15.TabIndex = 14;
            button15.Text = "CE";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button_clearEntery_click;
            // 
            // button16
            // 
            button16.Font = new Font("Segoe UI", 14F);
            button16.Location = new Point(12, 120);
            button16.Name = "button16";
            button16.Size = new Size(81, 67);
            button16.TabIndex = 13;
            button16.Text = "C";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button_Clear_click;
            // 
            // button1
            // 
            button1.BackColor = Color.LightCoral;
            button1.Font = new Font("Segoe UI", 14F);
            button1.Location = new Point(281, 193);
            button1.Name = "button1";
            button1.Size = new Size(89, 67);
            button1.TabIndex = 20;
            button1.Text = "*";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button_click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 14F);
            button2.Location = new Point(185, 193);
            button2.Name = "button2";
            button2.Size = new Size(90, 67);
            button2.TabIndex = 19;
            button2.Text = "9";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button_click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 14F);
            button3.Location = new Point(94, 193);
            button3.Name = "button3";
            button3.Size = new Size(85, 67);
            button3.TabIndex = 18;
            button3.Text = "8";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button_click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 14F);
            button4.Location = new Point(12, 193);
            button4.Name = "button4";
            button4.Size = new Size(81, 67);
            button4.TabIndex = 17;
            button4.Text = "7";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button_click;
            // 
            // button5
            // 
            button5.BackColor = Color.LightCoral;
            button5.Font = new Font("Segoe UI", 14F);
            button5.Location = new Point(281, 266);
            button5.Name = "button5";
            button5.Size = new Size(89, 67);
            button5.TabIndex = 24;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button_click;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 14F);
            button6.Location = new Point(185, 266);
            button6.Name = "button6";
            button6.Size = new Size(90, 67);
            button6.TabIndex = 23;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button_click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 14F);
            button7.Location = new Point(94, 266);
            button7.Name = "button7";
            button7.Size = new Size(85, 67);
            button7.TabIndex = 22;
            button7.Text = "5";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button_click;
            // 
            // button8
            // 
            button8.Font = new Font("Segoe UI", 14F);
            button8.Location = new Point(12, 266);
            button8.Name = "button8";
            button8.Size = new Size(81, 67);
            button8.TabIndex = 21;
            button8.Text = "4";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button_click;
            // 
            // button9
            // 
            button9.BackColor = Color.LightCoral;
            button9.Font = new Font("Segoe UI", 14F);
            button9.Location = new Point(281, 339);
            button9.Name = "button9";
            button9.Size = new Size(89, 67);
            button9.TabIndex = 28;
            button9.Text = "+";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button_click;
            // 
            // button10
            // 
            button10.Font = new Font("Segoe UI", 14F);
            button10.Location = new Point(185, 339);
            button10.Name = "button10";
            button10.Size = new Size(90, 67);
            button10.TabIndex = 27;
            button10.Text = "3";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button_click;
            // 
            // button11
            // 
            button11.Font = new Font("Segoe UI", 14F);
            button11.Location = new Point(94, 339);
            button11.Name = "button11";
            button11.Size = new Size(85, 67);
            button11.TabIndex = 26;
            button11.Text = "2";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button_click;
            // 
            // button12
            // 
            button12.Font = new Font("Segoe UI", 14F);
            button12.Location = new Point(12, 339);
            button12.Name = "button12";
            button12.Size = new Size(81, 67);
            button12.TabIndex = 25;
            button12.Text = "1";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button_click;
            // 
            // button17
            // 
            button17.BackColor = Color.LightCoral;
            button17.Font = new Font("Segoe UI", 14F);
            button17.Location = new Point(281, 412);
            button17.Name = "button17";
            button17.Size = new Size(89, 67);
            button17.TabIndex = 32;
            button17.Text = "=";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button_Equals_click;
            // 
            // button19
            // 
            button19.Font = new Font("Segoe UI", 14F);
            button19.Location = new Point(190, 412);
            button19.Name = "button19";
            button19.Size = new Size(85, 67);
            button19.TabIndex = 30;
            button19.Text = ".";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button_click;
            // 
            // button20
            // 
            button20.Font = new Font("Segoe UI", 14F);
            button20.Location = new Point(12, 412);
            button20.Name = "button20";
            button20.Size = new Size(172, 67);
            button20.TabIndex = 29;
            button20.Text = "0";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button_click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(381, 515);
            Controls.Add(button17);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(button4);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(txtOutput);
            Name = "Form1";
            Text = "Calulator";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtOutput;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button17;
        private Button button19;
        private Button button20;
    }
}
